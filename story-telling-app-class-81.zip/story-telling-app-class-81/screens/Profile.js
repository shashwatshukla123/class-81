import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default class Profile extends React.Component{
  render(){
  return (
    <View>
      <Text>welcome to profile</Text>
    </View>
  );
}
}