import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default class Feed extends React.Component{
  render(){
  return (
    <View>
      <Text>welcome to feed</Text>
    </View>
  );
}
}